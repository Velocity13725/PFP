# PFP Hub

A dark-mode desktop workspace for preparing one square profile picture and opening the official profile editors for Discord, Steam, Reddit, and YouTube. Runs on Windows and Linux.

## What it does
- Loads PNG, JPG, and WEBP images up to 20 MB.
- Previews the image and lets you choose crop-to-fill or fit-with-padding.
- Exports a square PNG at 256, 512, or 1024 pixels.
- Opens the official account/profile editor for each selected platform.
- Processes images locally. No account passwords, browser cookies, or session tokens are requested or stored.

## Important platform limitation
This version does **not** claim to automatically change avatars. The four services do not provide a supported, general-purpose consumer OAuth flow for changing a personal avatar through this desktop app. Use each platform's own editor to upload the exported PNG. This avoids private endpoints, self-bot behavior, and session-cookie handling.

## Run from source
Install Node.js 20+, then:

```bash
npm install
npm start
```

## Build installers

Windows (run on Windows):

```bash
npm install
npm run dist:win
```

Linux (run on Linux):

```bash
npm install
npm run dist:linux
```

Installers are written to `release/`. The GitHub Actions workflow builds a Windows `.exe` and Linux `.AppImage` on their respective runners. Push a tag such as `v1.0.0` to create a GitHub Release containing both files, or run the workflow manually to download build artifacts.

## Security
Electron uses context isolation, a sandboxed renderer, and a narrow allowlist for external platform links. Do not add features that request or store session cookies. The app does not upload your image anywhere.
