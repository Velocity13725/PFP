const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('node:path');

const ALLOWED = new Set([
  'https://discord.com', 'https://steamcommunity.com',
  'https://www.reddit.com', 'https://studio.youtube.com'
]);

function createWindow() {
  const win = new BrowserWindow({
    width: 1180, height: 820, minWidth: 900, minHeight: 680,
    backgroundColor: '#0b0d14', title: 'PFP Hub',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}

ipcMain.handle('open-platform', async (_event, raw) => {
  let url;
  try { url = new URL(raw); } catch { return false; }
  if (url.protocol !== 'https:' || !ALLOWED.has(url.origin)) return false;
  await shell.openExternal(url.href);
  return true;
});

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
