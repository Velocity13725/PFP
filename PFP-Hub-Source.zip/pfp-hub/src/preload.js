const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('pfpHub', {
  openPlatform: (url) => ipcRenderer.invoke('open-platform', url)
});
