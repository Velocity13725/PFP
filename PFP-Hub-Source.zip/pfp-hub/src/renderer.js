const fileInput = document.getElementById('fileInput');
const chooseBtn = document.getElementById('chooseBtn');
const dropzone = document.getElementById('dropzone');
const preview = document.getElementById('preview');
const emptyState = document.getElementById('emptyState');
const exportBtn = document.getElementById('exportBtn');
const fileMeta = document.getElementById('fileMeta');
const statusLine = document.getElementById('statusLine');
let currentImage = null;

function status(message, good = false) {
  statusLine.innerHTML = `<span class="status-dot" style="background:${good ? '#67d9c8' : '#9a8cff'}"></span><span>${message}</span>`;
}
function loadFile(file) {
  if (!file) return;
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
    status('Please choose a PNG, JPG, or WEBP image.'); return;
  }
  if (file.size > 20 * 1024 * 1024) { status('Image is too large. Maximum size is 20 MB.'); return; }
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      currentImage = img;
      preview.src = reader.result;
      preview.hidden = false;
      emptyState.hidden = true;
      fileMeta.textContent = `${file.name} · ${img.naturalWidth} × ${img.naturalHeight} · ${(file.size / 1024 / 1024).toFixed(2)} MB`;
      exportBtn.disabled = false;
      status('Image ready. Export a square PNG to use on your platforms.', true);
    };
    img.onerror = () => status('That image could not be opened.');
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}
chooseBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', e => loadFile(e.target.files[0]));
for (const eventName of ['dragenter', 'dragover']) dropzone.addEventListener(eventName, e => { e.preventDefault(); dropzone.style.borderColor = '#9a8cff'; });
for (const eventName of ['dragleave', 'drop']) dropzone.addEventListener(eventName, e => { e.preventDefault(); dropzone.style.borderColor = ''; });
dropzone.addEventListener('drop', e => loadFile(e.dataTransfer.files[0]));

document.getElementById('fitMode').addEventListener('change', e => { preview.style.objectFit = e.target.value; });
exportBtn.addEventListener('click', () => {
  if (!currentImage) return;
  const size = Number(document.getElementById('sizeMode').value);
  const mode = document.getElementById('fitMode').value;
  const canvas = document.createElement('canvas'); canvas.width = size; canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, size, size);
  const scale = mode === 'cover' ? Math.max(size / currentImage.width, size / currentImage.height) : Math.min(size / currentImage.width, size / currentImage.height);
  const w = currentImage.width * scale, h = currentImage.height * scale;
  ctx.drawImage(currentImage, (size - w) / 2, (size - h) / 2, w, h);
  canvas.toBlob(blob => {
    if (!blob) { status('Could not export this image.'); return; }
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = `PFP-Hub-${size}x${size}.png`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    status(`Exported ${size} × ${size} PNG. Upload it on each platform.`, true);
  }, 'image/png');
});

document.querySelectorAll('.open-btn').forEach(button => button.addEventListener('click', async () => {
  const ok = await window.pfpHub.openPlatform(button.dataset.url);
  status(ok ? `Opened ${button.closest('.platform').querySelector('.platform-info b').textContent}.` : 'Could not open that platform link.');
}));
document.getElementById('historyNav').addEventListener('click', () => status('Recent images are not saved. Choose a file to start a new session.'));
